import React from 'react'

const Footer = () => {
  return (
    <div className='p-2 bg-dark text-white text-center'><small>&copy; 2023 All rights reserved. Powered by <a href="/">OverClocked</a>.</small></div>
  )
}

export default Footer